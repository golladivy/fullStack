package javafullstack;

public class instance {
 int data=10;
 public static void main(String[] args) {
	 instance a1=new instance();
 System.out.println(a1.data);
 }
}
