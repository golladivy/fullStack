package javafullstack;

public class Staticvariable {
static int data=50;
 public static void main(String[] args) {
 System.out.println(Staticvariable.data);
 }
}
