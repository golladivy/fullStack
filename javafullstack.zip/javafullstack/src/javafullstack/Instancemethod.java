package javafullstack;

public class Instancemethod {
	int a=14;
	int display() {
		return 11;
	}
	public static void main(String args[])
	{
		Instancemethod i1=new Instancemethod();
		System.out.println(i1.a);
		System.out.println(i1.display());
	}

}
