package javafullstack;

public class Staticmethod {
static int a=14;
static int display() {
		return 11;
	}
	public static void main(String args[])
	{
		System.out.println(Staticmethod.a);
		System.out.println(Staticmethod.display());
	}
}

