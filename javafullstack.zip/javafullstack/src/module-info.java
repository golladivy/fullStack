/**
 * 
 */
/**
 * 
 */
module javafullstack {
}